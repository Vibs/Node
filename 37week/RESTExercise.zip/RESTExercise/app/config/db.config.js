module.exports = {
    HOST: "localhost",
    USER: "gruppe10",
    PASSWORD: "gruppe10",
    DB: "dank"
  };